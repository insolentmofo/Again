# M2 Config Fix

A tiny Android app that appends

```
[io]
file_first = true
```

to `Android/data/com.feralinteractive.medieval2_android/files/feral_app_support/VFS/Local/preferences/medieval2.preference.cfg`.
It checks first and won't add the block twice.

## Get the APK without installing anything (GitHub Actions)

1. Create a new repository on github.com and upload every file in this folder (keep the `.github/workflows` folder).
2. Open the **Actions** tab. The "Build APK" run starts on its own (or press **Run workflow**).
3. When it turns green, open the run and download **M2ConfigFix-apk** (a zip holding `app-debug.apk`).

## Or build locally

Open the folder in Android Studio and pick Build → Build APK(s), or run `gradle :app:assembleDebug` with the Android SDK installed.

## Using it

Launch Medieval II once first so the config file exists. Then open M2 Config Fix:

- **Apply fix**: Android 10 and older edit the file directly after you allow storage access. On Android 11+ a folder picker opens; tap *Use this folder* → *Allow*.
- **Apply with root**: for rooted phones (Magisk/KernelSU).
- **Pick the .cfg file manually**: for when your file picker can see the file.

Android 13/14+ often blocks every normal app from reaching another app's `Android/data` folder. If the picker won't allow it and you have no root, use a Shizuku-capable file manager or edit the file from a PC over USB.
